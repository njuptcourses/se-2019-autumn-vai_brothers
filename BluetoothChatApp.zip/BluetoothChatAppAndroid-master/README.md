# BluetoothChatAppAndroid
Make a simple chat application through bluetooth in Android
